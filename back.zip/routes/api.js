var express = require('express');
var fs = require('fs');
var router = express.Router();


var formRouter = express.Router({ mergeParams: true });
router.use('/forms/:id', formRouter)

router.get('/forms/', function(req, res, next) {
	fs.readFile('./database/forms.txt', (err, data) => {
    if (err) throw err;
		temp = JSON.parse(data);
		res.send(temp.forms);
	});
});

formRouter.get('/', function(req, res, next) {
	form_id = req.params.id
	fs.readFile('./database/forms.txt', (err, data) => {
    if (err) throw err;
		defiin = JSON.parse(data);
		var found = false;
		defiin.forms.forEach(el => {
			if (el.id == form_id) {
				found = true;
				res.send(el);
			}
		});
		if (!found) {
			res.status(404).send('')
		}
	})
});

formRouter.post('/submit/', function(req, res, next) {
	console.log(req.data)
	res.send("ok")
});

module.exports = router;
