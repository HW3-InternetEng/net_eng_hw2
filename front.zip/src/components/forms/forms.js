import React from 'react';
import { Link } from 'react-router-dom';
import css from './forms.module.css';
import axios from 'axios';

class Forms extends React.Component {
	state = {
		formsData: []
	}
	componentDidMount(){
      axios.get('http://127.0.0.1:8000/api/forms/')
  		.then((result) => {
    		this.setState({formsData: result.data});
  		})
  		.catch((err) => {
  			console.log(err)
  		});
    }
    render() { 
		var li_array = [];
		this.state.formsData.forEach(form => {
			li_array.push(<li><Link to={"/forms/"+ form.id}>{form.title}</Link></li>)
		});
    	return (
    		<ul className={css.forms + " text-right"}>{li_array}</ul>
    	);
    }
}

export default Forms;