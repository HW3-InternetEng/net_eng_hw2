import React from 'react';
import { Link } from 'react-router-dom';
import css from './form.module.css';
import axios from 'axios';

class Form extends React.Component {
	state = {
		errorGettingData: false,
		formData: {}
	}
	componentDidMount() {
		console.log(this.props.match.params.id);
		axios.get('http://127.0.0.1:8000/api/forms/' + this.props.match.params.id + '/')
		.then(result => {
			console.log(result.data)
			this.setState({formData: result.data });
		})
		.catch(err => {
			console.log(err);
			this.setState({errorGettingData: true});
		});
	}
	submitHandler(event) {
		event.preventDefault();
		console.log(this);
		let title = this.state.formData.title;
		let id = this.state.formData.id
		let data = {
			"title": title,
			"id": id,
			"fields": []
		}
		this.state.formData.fields.forEach(el => {
			this.data.push({
				"name": el.name,
				"value": document.getElementsByName(el.name).value
			});
		});
		console.log(data);
        axios.post( 'http://127.0.0.1:8000/api/forms/' + this.props.match.params.id + '/submit/', data)
        .then( result => {
        	if (result.data === "ok") {
        		this.props.history.push('/');
        	} else {
        		console.log('error');
        	}
        })
        .catch(err => {
        	console.log(err);    
        });
	}
	render() {
		if (Array.isArray(this.state.formData.fields)) {
			if (!this.state.formData.fields) {
				return null;
			}
		} else {
			return null;
		}
		var inputs = []
		this.state.formData.fields.forEach(field => {
			switch(field.type) {
				case "text":
					if (field.options && Array.isArray(field.options) && field.options.length) {
						var options = [];
						field.options.forEach(el => {
							options.push(<option value={el.value}>{el.label}</option>)
						});
						inputs.push(<select class="form-control" name={field.name}>{options}</select>);					
					} else {
						inputs.push(<div><p class="text-right mb-0">{field.title}:</p><input type="text" class="form-control" name={field.name}/></div>);
					}
					break;

				case "number":
					inputs.push(<div><p class="text-right mb-0">{field.title}:</p><input type="number" class="form-control" name={field.name} /></div>);
					break;
				case "date":
					inputs.push(<div><p class="text-right mb-0">{field.title}:</p><input type="date" class="form-control" name={field.name} /></div>)
					break;
				case "location":
					break;
			}
		});
		return (
			<form onSubmit={this.submitHandler}>
				<h4 class="text-center font-weight-bold">{this.state.formData.title}</h4>
				{inputs}
				<button class="btn btn-primary btn-block mt-3" type="submit">ارسال</button>
			</form>
		);
	}
}

export default Form;