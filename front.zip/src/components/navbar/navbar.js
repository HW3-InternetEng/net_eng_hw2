import React from 'react';
import { Link } from 'react-router-dom';

class Navbar extends React.Component {
	render() {
		return (
			<nav class="navbar navbar-expand-md navbar-dark bg-primary fixed-top shadow">
		      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggler" aria-controls="navbarToggler" aria-expanded="false" aria-label="Toggle navigation">
		        <span class="navbar-toggler-icon"></span>
		      </button>
		      <span>
		        <Link class="navbar-brand" to="/">اپ قشنگمون</Link>
		      </span>
		      <div class="collapse navbar-collapse" id="navbarToggler">
		        <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
		          <li class="nav-item">
		            <Link class="nav-link active" to="/">خانه</Link>
		          </li>
		          <li class="nav-item">
		            <Link class="nav-link active" to="/forms/">فرم‌ها</Link>
		          </li>
		        </ul>
		      </div>
		    </nav>
		);
	}
}

export default Navbar;