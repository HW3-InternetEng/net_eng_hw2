import React from 'react';
import { BrowserRouter, Switch, Route } from 'react-router-dom';
import Forms from './components/forms/forms.js'
import Form from './components/form/form.js'
import Navbar from './components/navbar/navbar.js'

function demoAsyncCall() {
	return new Promise((resolve) => setTimeout(() => resolve(), 50));
}

class App extends React.Component {
  state = {
    loading: true
  };

  componentDidMount() {
    demoAsyncCall().then(() => this.setState({ loading: false }));
  }
  
  render() {
    const { loading } = this.state;
    
    if(loading) { // if your component doesn't have to wait for an async action, remove this block 
      return null; // render null when app is not ready
    }
    
    return (<BrowserRouter>
        <div>
          <div class="row">
            <div class="col-xl-4 col-lg-4 col-md-2 col-sm-2 col-1"></div>
            <div class="col-xl-4 col-lg-4 col-md-8 col-sm-8 col-10 p-3 bg-white shadow-lg">
              <Navbar />
              <Switch>
                <Route path="/forms/:id"  component={Form} />
                <Route path="/forms/"  component={Forms} />
                <Route path="/"  component={Forms} />
              </Switch>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-2 col-sm-2 col-1"></div>
          </div>
        </div>
      </BrowserRouter>
    );
  }
}

export default App